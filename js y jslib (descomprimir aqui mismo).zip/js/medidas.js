/*
containerlayout.js
Manejo de contenedores y distribuciones (layout) con Sencha ExtJS
*/
Ext.require([
    'Ext.plugin.Viewport'
]);
Ext.application({
    name: '',
    launch : function() {
		var hijo1 = {   //creo un nodo del dom
				frame: true,
				height: '10em',
				html: '<p>Si el COVID-19 se propaga en su comunidad, manténgase seguro mediante la adopción de algunas sencillas medidas de precaución, por ejemplo,'+
						'mantener el distanciamiento físico, llevar mascarilla, ventilar bien las habitaciones, evitar las aglomeraciones, lavarse las manos y, al toser,'+
						'cubrirse la boca y la nariz con el codo flexionado o con un pañuelo.<br>Lo anterior mencionado son solo algunos ejemplos de lo que podemos hacer'+
						'para evitar contagiarnos con este temible virus, pero aqui les compartimos algunas medidas 100% recomendables a seguir para cuidarnos tanto a los'+
						'que nos rodean, como a nosotros mismos.</p>',
				title: ' <h1 class="animate__animated animate__backInLeft">¿Cómo podemos prevenir el COVID-19?</h1>',
				collapsible: true,
				collapsed: true,
			};
		var hijo2 = {
				frame: true,
				//height: '10em',
				height: '10em',
				html: '<center><table class="ui-widget-content">'+
				'<tr>'+
				  '<th><h1 class="animate__animated animate__backInLeft" >=====</h1></th>'+
				  '<th><h1 class="animate__animated animate__backInLeft" >Medidas preventivas</h1></th>'+
				  '<th><h1 class="animate__animated animate__backInLeft" >=====</h1></th>'+
				'</tr>'+
				'<tr>'+
				  '<th><b>EVITAR CONTACTO FÍSICO</b></th>'+
				  '<th><b>Evitar saludar ni de beso ni de mano. <br>Además, evite tocarte los ojos, <br>nariz y boaca con las manos sin lavar.</b></th>'+
				  '<th><img src="img/contacto.PNG" id="imagen2"/></th>'+
				'</tr>'+
				'<tr>'+
				  '<th><b>EVITAR SALIR DE CASA</b></th>'+
				  '<th><b>A menos que sea sumamente necesario, <br>evita salir de casa o estar en lugares públicos <br>y muy concurridos.</b></th>'+
				  '<th><img src="img/casa.PNG" id="imagen2"/></th>'+
				'</tr>'+
				'<tr>'+
				  '<th><b>LIMPIAR Y DESINFECTAR SUPERFICIES</b></th>'+
				  '<th><b>Limpia y desinfecta los objetos y superficies con las que tienes contacto. Evita compartir vasos, platos <br> y artículos de uso personal</b></th>'+
				  '<th><img src="img/limpia.PNG" id="imagen2"/></th>'+
				'</tr>'+
				'<tr>'+
				  '<th><b>PROTEGER A OTROS I</b></th>'+
				  '<th><b>Al toser o estornudar sobre tu boca <br> y nariz con la cara interna del <br> codo o usa un pañuelo.</b></th>'+
				  '<th><img src="img/proteger1.PNG" id="imagen2"/></th>'+
				'</tr>'+
				'<tr>'+
				  '<th><b>PROTEGER A OTROS II</b></th>'+
				  '<th><b>Si tienes fiebre, tos o dificultas para <br> respirar quétade en casa.</b></th>'+
				  '<th><img src="img/proteger2.PNG" id="imagen2"/></th>'+
				'</tr>'+
				'<tr>'+
				  '<th><b>FOMENTAR EL RESGUARDO EN CASA</b></th>'+
				  '<th><b>Promueve el trabajo desde casa para evitar<br> el uso de transporte público o lugares concurridos.</b></th>'+
				  '<th><img src="img/resguardo.PNG" id="imagen2"/></th>'+
				'</tr>'+
			  '</table></center>',
				title: ' <h1 class="animate__animated animate__backInLeft">MEDIDAS PREVENTIVAS</h1>',
				collapsible: true,
				collapsed: true
			};
		Ext.create('Ext.Panel', {  //creo el panel 
			renderTo: Ext.getBody(),  // acomoda en el body
			
			items: [     //adjunto los hijos
				hijo1, hijo2
			]
		});
	}
});

