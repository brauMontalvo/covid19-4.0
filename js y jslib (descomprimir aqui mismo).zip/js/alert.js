/*
propio.js
Ejemplo de mensaje a pantalla con Sencha ExtJS
*/
Ext.require([
    'Ext.plugin.Viewport'
]);
Ext.application({
    launch : function() {
		Ext.Msg.alert(
			'<h1>ADVERTENCIA</h1>',
			'<p>Sea honesto con sus respuestas, pues en base a ellas se hará un resultado aproximado de la gravedad en la que pueda o no encontrarse.</p>'
		);
	}
});

